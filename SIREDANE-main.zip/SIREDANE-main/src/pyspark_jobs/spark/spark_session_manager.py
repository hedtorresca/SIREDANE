import os

from dotenv import load_dotenv
from pyspark.sql import SparkSession, DataFrame

from config.db_config import DbConfig


class SparkSessionManager:

    def  __init__(self, app_name:str, spark_master:str):
        load_dotenv()
        self.app_name = app_name
        self.spark_master = spark_master
        self.db_config = DbConfig()
        self.temp_spark_folder = os.getenv("SPARK_TEMP_FOLDER")
        if self.temp_spark_folder is None:
            raise Exception("No se ha configurado la variable de entorno SPARK_TEMP_FOLDER")
        self.spark_session = self.__create_spark_session__()

    def get_spark_session(self):
        return self.spark_session


    def execute_query(self, query: str) -> DataFrame:

        if self.spark_session is None:
            raise Exception("No se puede ejectuar la query, la sesión de spark esta cerrada")

        connection_properties = {
            "user": self.db_config.jdbc_user,
            "password": self.db_config.jdbc_password,
            "driver": self.db_config.jdbc_driver
        }

        return self.spark_session.read.jdbc(
            url=self.db_config.jdbc_url,
            table=query,
            properties=connection_properties
        )

    def load_to_db(self, df: DataFrame, table_name: str, mode: str = "append"):
        try:
            df.write \
                .format("jdbc") \
                .option("url", self.db_config.jdbc_url) \
                .option("dbtable", table_name) \
                .option("user", self.db_config.jdbc_user) \
                .option("password", self.db_config.jdbc_password) \
                .option("driver", self.db_config.jdbc_driver) \
                .mode(mode) \
                .save()

        except Exception as e:
            raise Exception(f"Ocurrio un error al cargar el dataframe a la base de datos: {e}")

    def read_csv(self, header:bool, csv_path:str):
        return (self.spark_session.read.option("header", header)
              .option("inferSchema", "true").csv(csv_path))

    def stop_spark_session(self):
        self.spark_session.stop()

    def __create_spark_session__(self):
        return SparkSession.builder \
            .appName(self.app_name) \
            .master(self.spark_master) \
            .config("spark.jars.packages", "org.postgresql:postgresql:42.6.0,com.oracle.database.jdbc:ojdbc8:21.9.0.0") \
            .getOrCreate()