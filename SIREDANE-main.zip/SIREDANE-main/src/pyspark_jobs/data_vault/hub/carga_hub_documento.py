from pyspark.sql import DataFrame
from pyspark_jobs.audit.log_etl_command import LogETLCommand
from pyspark_jobs.data_vault.hub.hub_master_job import HubMasterJob
from pyspark_jobs.spark.spark_session_manager import SparkSessionManager


class CargaHubDocumento(HubMasterJob):

    def get_etl_log_command(self, md5_file: str) -> LogETLCommand:
        return LogETLCommand("Carga Hub Documento from raw_bdua",
                                  "staging_hub_documento",
                                  self.job_uuid,
                                  "Carga Hub documento",
                                  "Carga Hub documento a partir de la tabla raw_bdua",
                                  "", md5_file)

    def get_new_data(self, spark: SparkSessionManager, md5_file: str) -> DataFrame:
        return spark.execute_query(self.__query_afiliacion__(md5_file))

    def get_previous_data(self, spark: SparkSessionManager) -> DataFrame:
        return spark.execute_query(self.__query_hub_documento__())

    def __query_afiliacion__(self, md5_file:str) -> str:
        return f"""(select distinct a."NUMERO_IDENTIFICACION" as numero_documento
                   from raw_bdua a
                            inner join
                        raw_log_etl le
                        on (a.file_name = le.nombre_archivo)
                   where le.hash_archivo = '{md5_file}') as bdua """

    def __query_hub_documento__(self) -> str:
        return """
            ( select numero_documento as numero_documento_hub
             from staging_hub_documento ) as hub_documento
        """