import os
import logging
import uuid

from abc import ABC, abstractmethod
from datetime import datetime

from dotenv import load_dotenv
from pyspark.sql import DataFrame
from pyspark.sql.functions import udf, lit
from pyspark.sql.types import StringType

from pyspark_jobs.audit.log_etl_service import LogEtlService
from pyspark_jobs.audit.log_etl_command import LogETLCommand
from pyspark_jobs.hash.hash_calculator import HashCalculator
from pyspark_jobs.spark.spark_session_manager import SparkSessionManager


class HubMasterJob(ABC):

    def __init__(self, spark_app_name:str, table_name:str, md5_column_name:str,
                 right_join_column:str, left_join_column:str):
        load_dotenv()
        self.job_uuid = str(uuid.uuid4())
        self.spark_app_name = spark_app_name
        self.table_name =table_name
        self.md5_column_name = md5_column_name
        self.right_join_column = right_join_column
        self.left_join_column = left_join_column

    def load(self, md5_file_load:str, md5_file_save:str, id_source:int):
        spark_master = os.getenv("SPARK_MASTER")
        logging.info(f"Iniciando sesion en spark_session_manager {spark_master}")
        spark_session_manager = SparkSessionManager(app_name=self.spark_app_name, spark_master=spark_master)

        log_etl_service = LogEtlService(spark_session_manager)

        md5_udf = udf(self.__get_md5__, StringType())

        log_etl_service.start_job(self.get_etl_log_command(md5_file_save))

        new_data_df = self.get_new_data(spark_session_manager, md5_file_load)
        previous_data_df = self.get_previous_data(spark_session_manager)

        df = self.filter_new_data(new_data_df, previous_data_df, self.left_join_column, self.right_join_column)
        df = df.withColumn("load_datetime", lit(datetime.now()))
        df = df.withColumn("md5_hash", md5_udf(df[self.md5_column_name]))
        df = df.withColumn("id_fuente_registro", lit(id_source))

        id_log_etl = log_etl_service.end_job(df.count(), mensaje_error=None)

        df = df.withColumn("id_log_etl", lit(id_log_etl))
        spark_session_manager.load_to_db(df, self.table_name, mode="append")

        spark_session_manager.stop_spark_session()
        logging.info(f"Sesión de Spark cerrada")

    def __get_md5__(self, cadena:str) -> str:
        return HashCalculator.get_hash(str(cadena))

    @abstractmethod
    def get_etl_log_command(self, md5_file_save:str)->LogETLCommand:
        pass

    @abstractmethod
    def get_new_data(self, spark:SparkSessionManager, md5_file_load:str) -> DataFrame:
        pass

    @abstractmethod
    def get_previous_data(self, spark:SparkSessionManager)-> DataFrame:
        pass

    def filter_new_data(self, left_df:DataFrame, right_df:DataFrame, left_column:str, right_column:str) -> DataFrame:
        df = left_df.join(
            right_df,
            left_df[left_column] == right_df[right_column],
            how="left"
        )
        df = df.filter(df[right_column].isNull())
        return df.drop(right_column)