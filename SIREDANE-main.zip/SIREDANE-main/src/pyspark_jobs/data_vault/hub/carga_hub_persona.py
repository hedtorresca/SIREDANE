from pyspark.sql import DataFrame
from pyspark_jobs.audit.log_etl_command import LogETLCommand
from pyspark_jobs.data_vault.hub.hub_master_job import HubMasterJob
from pyspark_jobs.spark.spark_session_manager import SparkSessionManager


class CargaHubPersona(HubMasterJob):

    def get_etl_log_command(self, md5_file_save: str) -> LogETLCommand:
        return LogETLCommand("Carga Hub Persona from raw_bdua",
                                  "staging_hub_persona",
                                  self.job_uuid,
                                  "Carga Hub Persona",
                                  "Carga Hub Persona a partir de la tabla raw_bdua",
                                  "", md5_file_save)

    def get_new_data(self, spark: SparkSessionManager, md5_file_load: str) -> DataFrame:
        return spark.execute_query(self.__query_afiliacion__(md5_file_load))

    def get_previous_data(self, spark: SparkSessionManager) -> DataFrame:
        return spark.execute_query(self.__query_hub_entidad__())

    def __query_afiliacion__(self, md5_file_load:str) -> str:
        return f"""(select distinct a.\"id_estadistico_persona\"
                   from raw_bdua a
                            inner join
                        raw_log_etl le
                        on (a.\"file_name\" = le.nombre_archivo)
                   where le.hash_archivo = '{md5_file_load}') bdua """

    def __query_hub_entidad__(self) -> str:
        return """
            ( select id_estadistico_persona as id_estadistico_hub_persona
            from staging_hub_persona ) hub_persona
        """

