import uuid

from pyspark.sql.functions import udf, lit, concat_ws
from pyspark.sql.types import StringType

from pyspark_jobs.audit.log_etl_service import LogEtlService
from pyspark_jobs.audit.log_etl_command import LogETLCommand
from pyspark_jobs.hash.hash_calculator import HashCalculator
from pyspark_jobs.spark.spark_session_manager import SparkSessionManager


class SatPersona:

    def __init__(self):
        self.job_uuid = str(uuid.uuid4())

    def load(self, md5_file_load:str, md5_file_save:str, id_source:int):
        spark = SparkSessionManager(app_name="sat_persona_load", spark_master="local[*]")
        log_etl_service = LogEtlService(spark)
        md5_udf = udf(self.__get_md5__, StringType())
        log_etl_service.start_job(self.get_etl_log_command(md5_file_save))

        new_data_df = self.get_new_data(spark, md5_file_load)

        hub_persona_df = self.get_hub_persona_data(spark)

        previous_data_df = self.get_previous_data(spark)

        df = new_data_df.join(hub_persona_df, new_data_df["id_estadistico_persona"] == hub_persona_df["id_estadistico_hub_persona"], how="inner")
        df = df.withColumn(
            "md5_column",
            md5_udf(concat_ws(
                "",  # sin separador
                df["id_estadistico_persona"].cast("string"),
                df["sexo"].cast("string"),
                df["fecha_nacimiento"].cast("string"),
                df["discapacidad"].cast("string"),
                df["tipo_poblacion_especial"].cast("string"),
                df["etnia"].cast("string"),
                df["nombre_resguardo_indigena"].cast("string"),
            ))
        )
        df = df.withColumn("md5_hash", md5_udf(df["md5_column"]))

        new_data = df.join(previous_data_df, df["md5_hash"] == previous_data_df["md5_hash_previous"], how="left")
        new_data = new_data.filter(new_data["md5_hash_previous"].isNull())

        new_data = new_data.withColumn("id_fuente_registro", lit(id_source))
		
        load_id_log_etl = int(self.get_id_log_etl(spark, md5_file_load).collect()[0]["ID"])

        new_data = new_data.withColumn("id_log_etl", lit(load_id_log_etl))
        new_data = new_data.drop("md5_column")
        new_data = new_data.drop("md5_hash_previous")
        new_data = new_data.drop("id_estadistico_hub_persona")
        new_data = new_data.drop("id_estadistico_persona")
        new_data = new_data.withColumnRenamed("id", "id_hub_persona")
        spark.load_to_db(new_data, "staging_sat_persona", mode="append")

        id_log_etl = log_etl_service.end_job(df.count(), mensaje_error=None)
        spark.stop_spark_session()

    def __get_md5__(self, cadena:str) -> str:
        return HashCalculator.get_hash(str(cadena))

    def get_id_log_etl(self, spark, md5_file_load):
	    return spark.execute_query(self.__query_idlogetl__(md5_file_load))

    def __query_idlogetl__(self, md5_file_load:str) -> int:
        return f"""(select id from raw_log_etl where hash_archivo = '{md5_file_load}') sal_id_log_etl """

    def get_new_data(self, spark, md5_file_load):
        return spark.execute_query(self.__query_afiliacion__(md5_file_load))

    def __query_afiliacion__(self, md5_file_load:str) -> str:
        return f"""(select "id_estadistico_persona",
                            "SEXO" as sexo,
                            "FECHA_NACIMIENTO" as fecha_nacimiento,
                            "discapacidad",
                            "Tipo_poblacion_especial" as tipo_poblacion_especial,
                            "Etnia" as etnia,
                            "Nombre_resguardo" as nombre_resguardo_indigena
                   from raw_bdua a
                            inner join
                        raw_log_etl le
                        on (a."file_name" = le.nombre_archivo)
                   where le.hash_archivo = '{md5_file_load}') afiliacion """

    def get_previous_data(self, spark):
        return spark.execute_query(self.__query_sat_persona__())

    def __query_sat_persona__(self):
        return """( 
                    select md5_hash as md5_hash_previous
                    from staging_sat_persona ) sat_persona"""

    def get_hub_persona_data(self, spark):
        return spark.execute_query(self.__query_hub_persona__())

    def __query_hub_persona__(self):
        return """(select id, id_estadistico_persona as id_estadistico_hub_persona
                    from staging_hub_persona) hub_persona"""

    def get_etl_log_command(self, md5_file_save: str) -> LogETLCommand:
        return LogETLCommand("Carga Sat Persona from raw_bdua",
                                  "staging_sat_persona",
                                  self.job_uuid,
                                  "Carga Hub Persona",
                                  "Carga Hub Persona a partir de la tabla raw_bdua",
                                  "", md5_file_save)