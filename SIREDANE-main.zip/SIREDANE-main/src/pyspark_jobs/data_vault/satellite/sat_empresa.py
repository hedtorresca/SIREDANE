import uuid

from pyspark.sql.functions import udf, lit, concat_ws
from pyspark.sql.types import StringType

from pyspark_jobs.audit.log_etl_service import LogEtlService
from pyspark_jobs.audit.log_etl_command import LogETLCommand
from pyspark_jobs.hash.hash_calculator import HashCalculator
from pyspark_jobs.spark.spark_session_manager import SparkSessionManager


class SatEmpresa:

    def __init__(self):
        self.job_uuid = str(uuid.uuid4())

    def load(self, md5_file_load:str, md5_file_save:str, id_source:int):
        spark = SparkSessionManager(app_name="sat_empresa_load", spark_master="local[*]")
        log_etl_service = LogEtlService(spark)
        md5_udf = udf(self.__get_md5__, StringType())
        log_etl_service.start_job(self.get_etl_log_command(md5_file_save))

        new_data_df = self.get_new_data(spark, md5_file_load)

        hub_empresa_df = self.get_hub_empresa_data(spark)

        previous_data_df = self.get_previous_data(spark)

        df = new_data_df.join(hub_empresa_df, new_data_df["id_estadistico_empresa"] == hub_empresa_df["id_estadistico_hub_empresa"], how="inner")
        df = df.withColumn(
            "md5_column",
            md5_udf(concat_ws(
                "",  # sin separador
                df["id_estadistico_empresa"].cast("string"),
                df["codigo_camara"].cast("string"),
                df["camara_comercio"].cast("string"),
                df["matricula"].cast("string"),
                df["inscripcion_proponente"].cast("string"),
                df["sigla"].cast("string"),
                df["fecha_matricula"].cast("string"),
                df["fecha_renovacion"].cast("string"),
                df["ultimo_anio_renovado"].cast("string"),
                df["fecha_vigencia"].cast("string"),
                df["fecha_cancelacion"].cast("string"),
                df["codigo_tipo_sociedad"].cast("string"),
                df["tipo_sociedad"].cast("string"),
                df["codigo_organizacion_juridica"].cast("string"),
                df["organizacion_juridica"].cast("string"),
                df["codigo_categoria_matricula"].cast("string"),
                df["categoria_matricula"].cast("string"),
                df["codigo_estado_matricula"].cast("string"),
                df["estado_matricula"].cast("string"),
                df["fecha_actualizacion"].cast("string"),
                df["codigo_clase_identificacion"].cast("string"),
                df["digito_verificacion"].cast("string"),
                df["estatus"].cast("string"),
            ))
        )
        df = df.withColumn("md5_hash", md5_udf(df["md5_column"]))

        new_data = df.join(previous_data_df, df["md5_hash"] == previous_data_df["md5_hash_previous"], how="left")
        new_data = new_data.filter(new_data["md5_hash_previous"].isNull())

        new_data = new_data.withColumn("id_fuente_registro", lit(id_source))
		
        load_id_log_etl = int(self.get_id_log_etl(spark, md5_file_load).collect()[0]["ID"])

        new_data = new_data.withColumn("id_log_etl", lit(load_id_log_etl))
        new_data = new_data.drop("md5_column")
        new_data = new_data.drop("md5_hash_previous")
        new_data = new_data.drop("id_estadistico_hub_empresa")
        new_data = new_data.drop("id_estadistico_empresa")
        new_data = new_data.withColumnRenamed("id", "id_hub_empresa")
        spark.load_to_db(new_data, "staging_sat_empresa", mode="append")

        id_log_etl = log_etl_service.end_job(df.count(), mensaje_error=None)
        spark.stop_spark_session()

    def __get_md5__(self, cadena:str) -> str:
        return HashCalculator.get_hash(str(cadena))

    def get_id_log_etl(self, spark, md5_file_load):
	    return spark.execute_query(self.__query_idlogetl__(md5_file_load))

    def __query_idlogetl__(self, md5_file_load:str) -> int:
        return f"""(select id from raw_log_etl where hash_archivo = '{md5_file_load}') sal_id_log_etl """

    def get_new_data(self, spark, md5_file_load):
        return spark.execute_query(self.__query_empresa__(md5_file_load))

    def __query_empresa__(self, md5_file_load:str) -> str:
        return f"""(select "id_estadistico_empresa",
                            "codigo_camara" as codigo_camara,
                            "camara_comercio" as camara_comercio,
                            "matricula" as matricula,
                            "inscripcion_proponente" as inscripcion_proponente,
                            "sigla" as sigla,
                            "fecha_matricula" as fecha_matricula,
                            "fecha_renovacion" as fecha_renovacion,
                            "ultimo_anio_renovado" as ultimo_anio_renovado,
                            "fecha_vigencia" as fecha_vigencia,
                            "fecha_cancelacion" as fecha_cancelacion,
                            "codigo_tipo_sociedad" as codigo_tipo_sociedad,
                            "tipo_sociedad" as tipo_sociedad,
                            "codigo_organizacion_juridica" as codigo_organizacion_juridica,
                            "organizacion_juridica" as organizacion_juridica,
                            "codigo_categoria_matricula" as codigo_categoria_matricula,
                            "categoria_matricula" as categoria_matricula,
                            "codigo_estado_matricula" as codigo_estado_matricula,
                            "estado_matricula" as estado_matricula,
                            "fecha_actualizacion" as fecha_actualizacion,
                            "codigo_clase_identificacion" as codigo_clase_identificacion,
                            "digito_verificacion" as digito_verificacion,
                            "estatus" as estatus
                   from raw_rues a
                            inner join
                        raw_log_etl le
                        on (a."file_name" = le.nombre_archivo)
                   where le.hash_archivo = '{md5_file_load}') empresa """

    def get_previous_data(self, spark):
        return spark.execute_query(self.__query_sat_empresa__())

    def __query_sat_empresa__(self):
        return """( 
                    select md5_hash as md5_hash_previous
                    from staging_sat_empresa ) sat_empresa"""

    def get_hub_empresa_data(self, spark):
        return spark.execute_query(self.__query_hub_empresa__())

    def __query_hub_empresa__(self):
        return """(select id, id_estadistico_empresa as id_estadistico_hub_empresa
                    from staging_hub_empresa) hub_empresa"""

    def get_etl_log_command(self, md5_file_save: str) -> LogETLCommand:
        return LogETLCommand("Carga Sat Empresa from raw_rues",
                                  "staging_sat_empresa",
                                  self.job_uuid,
                                  "Carga Hub Empresa",
                                  "Carga Hub Empresa a partir de la tabla raw_rues",
                                  "", md5_file_save)
