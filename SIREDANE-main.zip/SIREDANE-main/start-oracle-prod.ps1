# Script de inicio para Oracle en producción
# Ejecuta el sistema SIRE con Oracle como base de datos de destino

Write-Host "🚀 Iniciando SIRE con Oracle en Producción..." -ForegroundColor Green
Write-Host "=" * 60 -ForegroundColor Cyan

# Verificar que Docker esté ejecutándose
Write-Host "🔍 Verificando Docker..." -ForegroundColor Yellow
try {
    docker version | Out-Null
    Write-Host "✅ Docker está ejecutándose" -ForegroundColor Green
} catch {
    Write-Host "❌ Docker no está ejecutándose. Por favor inicia Docker Desktop." -ForegroundColor Red
    exit 1
}

# Verificar que el archivo de configuración existe
$configFile = "config\prod.oracle.env"
if (-not (Test-Path $configFile)) {
    Write-Host "❌ Archivo de configuración no encontrado: $configFile" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Archivo de configuración encontrado" -ForegroundColor Green

# Crear directorio de logs si no existe
if (-not (Test-Path "logs")) {
    New-Item -ItemType Directory -Path "logs" | Out-Null
    Write-Host "✅ Directorio de logs creado" -ForegroundColor Green
}

# Detener contenedores existentes
Write-Host "🛑 Deteniendo contenedores existentes..." -ForegroundColor Yellow
docker-compose -f docker-compose.oracle.prod.yml down

# Construir imágenes si es necesario
Write-Host "🔨 Construyendo imágenes de Docker..." -ForegroundColor Yellow
docker-compose -f docker-compose.oracle.prod.yml build

# Inicializar la base de datos
Write-Host "🗄️  Inicializando estructura de base de datos..." -ForegroundColor Yellow
docker-compose -f docker-compose.oracle.prod.yml run --rm sire-db-init

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Error inicializando la base de datos" -ForegroundColor Red
    Write-Host "   Verifica que tengas acceso a Oracle en 10.168.48.79:1522" -ForegroundColor Yellow
    exit 1
}

# Iniciar servicios
Write-Host "🚀 Iniciando servicios..." -ForegroundColor Yellow
docker-compose -f docker-compose.oracle.prod.yml up -d

# Esperar a que los servicios estén listos
Write-Host "⏳ Esperando a que los servicios estén listos..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

# Verificar estado de los servicios
Write-Host "🔍 Verificando estado de los servicios..." -ForegroundColor Yellow

# Verificar FastAPI
try {
    $response = Invoke-RestMethod -Uri "http://localhost:5003/" -TimeoutSec 10
    Write-Host "✅ FastAPI está ejecutándose en http://localhost:5003" -ForegroundColor Green
    Write-Host "   Mensaje: $($response.message)" -ForegroundColor Gray
} catch {
    Write-Host "❌ FastAPI no está respondiendo" -ForegroundColor Red
}

# Verificar Airflow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8080/health" -TimeoutSec 10
    if ($response.StatusCode -eq 200) {
        Write-Host "✅ Airflow está ejecutándose en http://localhost:8080" -ForegroundColor Green
    }
} catch {
    Write-Host "⚠️  Airflow puede estar iniciando aún..." -ForegroundColor Yellow
}

Write-Host "`n" + "=" * 60 -ForegroundColor Cyan
Write-Host "🎉 ¡Sistema SIRE iniciado exitosamente!" -ForegroundColor Green
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "📋 Servicios disponibles:" -ForegroundColor White
Write-Host "   • FastAPI: http://localhost:5003" -ForegroundColor Cyan
Write-Host "   • Airflow: http://localhost:8080" -ForegroundColor Cyan
Write-Host "   • PostgreSQL: localhost:5432" -ForegroundColor Cyan
Write-Host ""
Write-Host "📖 Documentación de la API:" -ForegroundColor White
Write-Host "   • Swagger UI: http://localhost:5003/docs" -ForegroundColor Cyan
Write-Host "   • ReDoc: http://localhost:5003/redoc" -ForegroundColor Cyan
Write-Host ""
Write-Host "🔧 Comandos útiles:" -ForegroundColor White
Write-Host "   • Ver logs: docker-compose -f docker-compose.oracle.prod.yml logs -f" -ForegroundColor Gray
Write-Host "   • Detener: docker-compose -f docker-compose.oracle.prod.yml down" -ForegroundColor Gray
Write-Host "   • Probar conexión: python scripts_oracle\test_oracle_prod.py" -ForegroundColor Gray
Write-Host ""
Write-Host "⚠️  Credenciales de Airflow:" -ForegroundColor Yellow
Write-Host "   • Usuario: admin" -ForegroundColor Gray
Write-Host "   • Contraseña: admin" -ForegroundColor Gray
Write-Host ""

# Preguntar si quiere ejecutar las pruebas
$runTests = Read-Host "¿Deseas ejecutar las pruebas de conexión? (s/n)"
if ($runTests -eq "s" -or $runTests -eq "S" -or $runTests -eq "y" -or $runTests -eq "Y") {
    Write-Host "🧪 Ejecutando pruebas de conexión..." -ForegroundColor Yellow
    python scripts_oracle\test_oracle_prod.py
}

Write-Host "`n✅ ¡Listo! El sistema está ejecutándose." -ForegroundColor Green