# Script para iniciar el proyecto con Oracle como destino
Write-Host "🚀 Iniciando SIRE con Oracle como destino de datos..." -ForegroundColor Green

# Copiar archivo de configuración
Copy-Item "config/dev.oracle.env" ".env" -Force
Write-Host "✅ Configuración Oracle aplicada" -ForegroundColor Green

# Iniciar servicios
Write-Host "🐳 Iniciando contenedores Docker..." -ForegroundColor Yellow
docker-compose -f docker-compose.oracle.yml up -d

Write-Host "⏳ Esperando a que los servicios estén listos..." -ForegroundColor Yellow
Start-Sleep -Seconds 60

Write-Host "🎉 SIRE iniciado exitosamente!" -ForegroundColor Green
Write-Host "📊 Airflow Web UI: http://localhost:8080" -ForegroundColor Cyan
Write-Host "🔧 FastAPI: http://localhost:8001" -ForegroundColor Cyan
Write-Host "📈 Spark Master: http://localhost:8081" -ForegroundColor Cyan
Write-Host "💾 Oracle DB: localhost:1521" -ForegroundColor Cyan
Write-Host "💾 PostgreSQL Airflow: localhost:5432" -ForegroundColor Cyan
