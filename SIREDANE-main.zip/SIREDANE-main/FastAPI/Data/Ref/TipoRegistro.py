TipoRegistro = {
    "Persona": "001",
    "Empresa": "002",
    "Otro":    "003"
    }