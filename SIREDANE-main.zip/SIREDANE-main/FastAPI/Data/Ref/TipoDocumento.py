TipoDocumento = {
    "Cédula de Ciudadanía": "CC",
    "NIT": "NIT",
    "Otro":    "OTR"
    }

##ACTUALIZAR A DANE