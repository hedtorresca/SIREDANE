from pyspark_jobs.data_vault.satellite.sat_persona import SatPersona
from pyspark_jobs.hash.hash_calculator import HashCalculator

if __name__ == "__main__":
    # Viene de raw_log_etl.hash_archivo obtenido luego de carga_csv_db.py
    md5_file_load = "37b11c531577bc307c9dc606abc673d8646aec2ed0b865f65e17e1aa6c4c449f"
	
    md5_file_save = HashCalculator.get_hash("SatPersona_" + md5_file_load)
	
	# Escribe a staging_hub_persona.id_fuente_registro
    id_source = 1

    # Crear instancia de SatPersona
    job = SatPersona()

    # Ejecutar el proceso de carga
    job.load(md5_file_load=md5_file_load, md5_file_save=md5_file_save, id_source=id_source)
